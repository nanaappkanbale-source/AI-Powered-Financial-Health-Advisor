from typing import Tuple

def calculate_dti(monthly_debt_payments: float, gross_monthly_income: float) -> float:
    """
    Calculates Debt-to-Income (DTI) ratio.
    Formula: (Total Monthly Debt Payments / Gross Monthly Income) * 100
    Returns percentage rounded to 2 decimal places.
    """
    if gross_monthly_income <= 0:
        return 0.0
    dti = (monthly_debt_payments / gross_monthly_income) * 100.0
    return round(dti, 2)

def calculate_credit_utilization(outstanding_credit: float, total_credit_limit: float) -> float:
    """
    Calculates Credit Utilization Ratio.
    Formula: (Outstanding Credit / Total Credit Limit) * 100
    Returns percentage rounded to 2 decimal places.
    """
    if total_credit_limit <= 0:
        return 0.0
    utilization = (outstanding_credit / total_credit_limit) * 100.0
    return round(utilization, 2)

def recalculate_profile_metrics(
    income: float,
    expenses: float,
    credit_limit: float,
    outstanding_credit_or_debt: float,
    monthly_emi: float
) -> Tuple[float, float]:
    """
    Recalculates both DTI ratio and Credit Utilization.
    Returns (dti_ratio, credit_utilization).
    """
    dti = calculate_dti(monthly_debt_payments=monthly_emi, gross_monthly_income=income)
    utilization = calculate_credit_utilization(
        outstanding_credit=outstanding_credit_or_debt,
        total_credit_limit=credit_limit
    )
    return dti, utilization
