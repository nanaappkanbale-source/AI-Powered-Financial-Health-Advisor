from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
import json
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.models.loan import Loan
from backend.models.ai_recommendation import AIRecommendation
from backend.services.calculations import recalculate_profile_metrics

def load_demo_data_for_user(user_id: int, db: Session):
    """
    Populates comprehensive, realistic Indian financial demo data for seamless project demonstration.
    """
    now = datetime.now(timezone.utc)
    
    # 1. Clean existing records for this user to avoid duplicates
    db.query(Loan).filter(Loan.user_id == user_id).delete()
    db.query(CreditScoreHistory).filter(CreditScoreHistory.user_id == user_id).delete()
    db.query(AIRecommendation).filter(AIRecommendation.user_id == user_id).delete()
    
    # 2. Setup Loans
    loans_data = [
        Loan(
            user_id=user_id,
            loan_name="HDFC Personal Loan (Home Renovation)",
            principal_amount=150000.0,
            outstanding_amount=120000.0,
            emi=6500.0,
            interest_rate=11.5,
            start_date=(now - timedelta(days=180)).strftime("%Y-%m-%d"),
            end_date=(now + timedelta(days=540)).strftime("%Y-%m-%d"),
            status="Active"
        ),
        Loan(
            user_id=user_id,
            loan_name="SBI Auto Loan (Maruti Brezza)",
            principal_amount=500000.0,
            outstanding_amount=80000.0,
            emi=3500.0,
            interest_rate=9.2,
            start_date=(now - timedelta(days=700)).strftime("%Y-%m-%d"),
            end_date=(now + timedelta(days=120)).strftime("%Y-%m-%d"),
            status="Active"
        ),
        Loan(
            user_id=user_id,
            loan_name="ICICI Consumer Durable Loan (Laptop)",
            principal_amount=60000.0,
            outstanding_amount=0.0,
            emi=0.0,
            interest_rate=12.0,
            start_date=(now - timedelta(days=400)).strftime("%Y-%m-%d"),
            end_date=(now - timedelta(days=40)).strftime("%Y-%m-%d"),
            status="Closed"
        )
    ]
    for loan in loans_data:
        db.add(loan)
    db.flush()

    # 3. Setup Credit Score History (demonstrating progress: 680 -> 705 -> 735)
    histories = [
        CreditScoreHistory(
            user_id=user_id,
            credit_score=680,
            score_change=0,
            recorded_at=now - timedelta(days=90)
        ),
        CreditScoreHistory(
            user_id=user_id,
            credit_score=705,
            score_change=25,
            recorded_at=now - timedelta(days=45)
        ),
        CreditScoreHistory(
            user_id=user_id,
            credit_score=735,
            score_change=30,
            recorded_at=now
        )
    ]
    for h in histories:
        db.add(h)

    # 4. Setup Financial Profile
    income = 50000.0
    expenses = 25000.0
    total_debt = 200000.0 # Active outstanding loans (120k + 80k)
    credit_limit = 100000.0
    monthly_emi = 10000.0 # 6,500 + 3,500
    missed_payments = 1
    credit_score = 735
    financial_goal = "Achieve 750+ CIBIL Score for Home Loan Approval"

    # DTI = (10,000 / 50,000) * 100 = 20.0%
    # Outstanding credit on cards ~ ₹35,000 -> 35% utilization
    dti, _ = recalculate_profile_metrics(income, expenses, credit_limit, 35000.0, monthly_emi)
    utilization = 35.0

    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == user_id).first()
    if not profile:
        profile = FinancialProfile(user_id=user_id)
        db.add(profile)
    
    profile.income = income
    profile.expenses = expenses
    profile.credit_score = credit_score
    profile.total_debt = total_debt
    profile.credit_limit = credit_limit
    profile.credit_utilization = utilization
    profile.dti_ratio = dti
    profile.missed_payments = missed_payments
    profile.active_loans = 2
    profile.monthly_emi = monthly_emi
    profile.financial_goal = financial_goal
    profile.updated_at = now

    # 5. Preload an AI Recommendation
    ai_sample = {
        "summary": "Rajesh's credit profile shows strong recovery momentum, having advanced from 680 to 735 over the last 90 days. His DTI ratio of 20.0% is healthy, though his credit utilization of 35% is slightly above the prime 30% threshold.",
        "health_status": "Good",
        "key_issues": [
            "Credit card utilization sits at 35%, marginally above the recommended 30% ceiling.",
            "1 historical delayed EMI payment recorded in the last 24 months.",
            "Total outstanding unsecured debt of ₹1,20,000 from personal loan."
        ],
        "action_plan": [
            "Step 1: Reduce credit card balances by ₹5,000 to bring utilization below 30% before the next billing cycle.",
            "Step 2: Automate monthly EMI payments of ₹10,000 via NACH/e-mandate to avoid inadvertent delays.",
            "Step 3: Close the remaining ₹80,000 on the SBI Auto Loan within the next 4 months to drop DTI from 20% to 13%.",
            "Step 4: Refrain from applying for new consumer credit cards or personal loans over the next 6 months to minimize hard inquiries.",
            "Step 5: Maintain healthy balance between secured auto loan and unsecured personal loan, and pull free annual CIBIL report every 6 months."
        ],
        "recommendations": [
            "Request a credit limit enhancement with HDFC Bank without taking additional credit to instantly reduce utilization percentage.",
            "Establish an emergency fund equivalent to 3 months of EMIs (₹30,000) in a high-yield liquid mutual fund or sweep-in FD.",
            "Prepay high-interest personal loan principal whenever performance bonuses or tax refunds are credited."
        ],
        "risk_factors": [
            "Single missed payment penalty will diminish over the next 12 months provided no new delays occur.",
            "Elevated credit card balances increase revolving interest charges at typical Indian APRs of 36-42%."
        ],
        "goal_strategy": "To achieve 750+ for prime home loan eligibility: bringing credit card utilization down to 25% and sustaining zero missed payments for the next 90 days should reliably propel your score beyond 750.",
        "educational_disclaimer": "Educational Notice: This AI analysis is generated for educational and informational purposes only and does not constitute formal banking, credit rating, or certified financial advice."
    }

    rec = AIRecommendation(
        user_id=user_id,
        summary=ai_sample["summary"],
        health_status=ai_sample["health_status"],
        recommendations=json.dumps(ai_sample),
        created_at=now
    )
    db.add(rec)
    db.commit()
    db.refresh(profile)
    return profile

def clear_user_demo_data(user_id: int, db: Session):
    """Resets user data to clean fresh state."""
    db.query(Loan).filter(Loan.user_id == user_id).delete()
    db.query(CreditScoreHistory).filter(CreditScoreHistory.user_id == user_id).delete()
    db.query(AIRecommendation).filter(AIRecommendation.user_id == user_id).delete()
    
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == user_id).first()
    if profile:
        profile.income = 0.0
        profile.expenses = 0.0
        profile.credit_score = 650
        profile.total_debt = 0.0
        profile.credit_limit = 0.0
        profile.credit_utilization = 0.0
        profile.dti_ratio = 0.0
        profile.missed_payments = 0
        profile.active_loans = 0
        profile.monthly_emi = 0.0
        profile.financial_goal = "Improve CIBIL Score to 750+"
    db.commit()
