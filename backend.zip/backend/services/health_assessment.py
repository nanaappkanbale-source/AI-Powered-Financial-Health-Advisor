from typing import List, Dict, Any

def assess_credit_health(
    credit_score: int,
    dti_ratio: float,
    credit_utilization: float,
    missed_payments: int,
    income: float = 0,
    expenses: float = 0,
    score_change: int = 0
) -> Dict[str, Any]:
    """
    Evaluates financial health and generates transparent, understandable reasons.
    Clearly labeled as internal assessment based on standard Indian credit benchmarks.
    """
    reasons: List[str] = []
    
    # 1. Credit Score Bracket
    if credit_score >= 750:
        base_status = "Excellent"
        color = "emerald"
        reasons.append(f"Your CIBIL score of {credit_score} is in the prime tier (750+), indicating high creditworthiness for Indian banks.")
    elif credit_score >= 700:
        base_status = "Good"
        color = "blue"
        reasons.append(f"Your CIBIL score of {credit_score} is healthy (700-749), qualifying for most loan and credit card products.")
    elif credit_score >= 650:
        base_status = "Fair"
        color = "amber"
        reasons.append(f"Your CIBIL score of {credit_score} is moderate (650-699). Lenders may charge higher interest rates.")
    else:
        base_status = "Needs Attention"
        color = "rose"
        reasons.append(f"Your CIBIL score of {credit_score} is below 650, which signals higher credit risk to financial institutions.")

    # 2. Credit Utilization Analysis (Indian Benchmark: <30% ideal)
    if credit_utilization > 50:
        reasons.append(f"High credit utilization ({credit_utilization}%): Using over 50% of your credit limit severely drags down your CIBIL score.")
        if base_status in ["Excellent", "Good"]:
            base_status = "Fair"
            color = "amber"
    elif credit_utilization > 30:
        reasons.append(f"Moderate credit utilization ({credit_utilization}%): Aim to keep your utilization under 30% for rapid score recovery.")
    elif credit_utilization > 0:
        reasons.append(f"Optimal credit utilization ({credit_utilization}%): Staying comfortably below the 30% benchmark protects your score.")
    else:
        reasons.append("Zero credit card utilization recorded. Maintaining active, well-managed revolving credit builds score depth.")

    # 3. Debt-to-Income (DTI) Analysis (Indian Benchmark: <35% safe)
    if dti_ratio > 50:
        reasons.append(f"Critical DTI ratio ({dti_ratio}%): More than half your monthly income goes toward EMIs/debts, leaving little financial cushion.")
        base_status = "Needs Attention"
        color = "rose"
    elif dti_ratio > 35:
        reasons.append(f"Elevated DTI ratio ({dti_ratio}%): Banks in India prefer debt commitments under 35-40% for new loan approvals.")
    elif dti_ratio > 0:
        reasons.append(f"Healthy DTI ratio ({dti_ratio}%): Debt service is well within comfortable repayment capacity.")

    # 4. Missed Payments Impact
    if missed_payments > 0:
        reasons.append(f"{missed_payments} missed/delayed payment(s) reported: Payment history accounts for ~35% of Indian credit bureau scoring.")
        if missed_payments >= 2:
            base_status = "Needs Attention"
            color = "rose"
    else:
        reasons.append("Clean payment track record with zero missed payments reported.")

    # 5. Score Trajectory
    if score_change > 0:
        reasons.append(f"Positive momentum: You have improved your credit score by +{score_change} points.")
    elif score_change < 0:
        reasons.append(f"Score dip: Your score decreased by {abs(score_change)} points recently. Check utilization and inquiry history.")

    # Summary sentence
    summary = f"Your overall credit profile is assessed as '{base_status}'. "
    if base_status == "Excellent":
        summary += "You are in an optimal position for low-interest loans and premium cards."
    elif base_status == "Good":
        summary += "Focus on keeping credit utilization below 30% to break into the 750+ prime tier."
    elif base_status == "Fair":
        summary += "Reducing revolving balances and strictly avoiding missed EMIs will steadily raise your score."
    else:
        summary += "Immediate debt consolidation and on-time EMI repayments are required to rebuild creditworthiness."

    return {
        "status": base_status,
        "color": color,
        "score": credit_score,
        "summary": summary,
        "reasons": reasons,
        "disclaimer": "Internal application assessment based on standard Indian credit benchmarks. Not an official bureau rating."
    }
