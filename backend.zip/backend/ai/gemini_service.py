import json
import logging
from typing import Dict, Any, List
import httpx
from backend.utils.config import settings

logger = logging.getLogger(__name__)

DISCLAIMER_TEXT = (
    "Educational Notice: This AI analysis is provided for educational and informational purposes only and does "
    "not constitute formal banking, certified financial planning, or official credit bureau advice. Official credit "
    "evaluations are performed exclusively by licensed credit bureaus in India (TransUnion CIBIL, Experian, Equifax, CRIF High Mark)."
)

def _build_intelligent_fallback_advice(user_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Intelligent rule-based Indian credit advisory engine used when GEMINI_API_KEY is not configured
    or when API rate limits/network outages occur. Fully customized to the user's live profile.
    """
    score = user_data.get("credit_score", 650)
    income = user_data.get("income", 0.0)
    expenses = user_data.get("expenses", 0.0)
    debt = user_data.get("total_debt", 0.0)
    limit = user_data.get("credit_limit", 0.0)
    utilization = user_data.get("credit_utilization", 0.0)
    dti = user_data.get("dti_ratio", 0.0)
    missed = user_data.get("missed_payments", 0)
    loans_count = user_data.get("active_loans", 0)
    emi = user_data.get("monthly_emi", 0.0)
    goal = user_data.get("financial_goal", "Improve CIBIL Score")

    # Determine Health Status
    if score >= 750 and utilization <= 30 and dti <= 35 and missed == 0:
        health_status = "Excellent"
    elif score >= 700 and dti <= 45 and missed <= 1:
        health_status = "Good"
    elif score >= 650:
        health_status = "Fair"
    else:
        health_status = "Needs Attention"

    # Identify Key Issues
    key_issues: List[str] = []
    if utilization > 50:
        key_issues.append(f"High credit utilization ({utilization}%): Consuming more than half your card limit significantly depresses your score.")
    elif utilization > 30:
        key_issues.append(f"Borderline credit utilization ({utilization}%): Aim for under 30% to maximize CIBIL algorithm benefits.")
    
    if dti > 45:
        key_issues.append(f"High Debt-to-Income ratio ({dti}%): Over 45% of monthly income is committed to EMIs, creating financial vulnerability.")
    elif dti > 35:
        key_issues.append(f"Moderate Debt-to-Income ratio ({dti}%): Indian lenders prefer DTI under 35% for prime loan terms.")
    
    if missed > 0:
        key_issues.append(f"{missed} missed payment(s) in record: Delinquencies carry heavy negative weight across Indian credit bureaus.")
    
    if income > 0 and (income - expenses - emi) < (income * 0.15):
        key_issues.append("Low monthly savings margin: Monthly expenses and EMIs consume more than 85% of incoming earnings.")
    
    if loans_count > 3:
        key_issues.append(f"High number of simultaneous active credit lines ({loans_count} active loans).")

    if not key_issues:
        key_issues.append("No critical credit red flags detected. Maintain disciplined repayment routines.")

    # 5-Step Action Plan
    action_plan = [
        f"Step 1 - Optimize Revolving Balances: Reduce credit card spend to achieve <30% utilization (Target: ₹{limit * 0.3:,.0f} or less)." if limit > 0 else "Step 1: Ensure active credit lines are maintained responsibly with on-time payments.",
        "Step 2 - Eliminate Delinquencies: Set up automated NACH mandates or banking autopay 3 days prior to EMI due dates.",
        f"Step 3 - Expedite Debt Retirement: Direct any surplus income toward clearing high-interest unsecured loans (Current total debt: ₹{debt:,.0f}).",
        "Step 4 - Curtail Credit Inquiries: Pause fresh loan or credit card applications for 6 months to curb hard bureau inquiries.",
        "Step 5 - Routine Bureau Audit: Request your free annual statutory credit report to verify that closed loans are marked 'NOC / Closed' with zero reporting errors."
    ]

    # Personalized Recommendations
    recommendations = [
        f"Maintain an emergency liquidity fund of at least ₹{emi * 3:,.0f} (3 months of EMI) in an instant-access bank account.",
        "Maintain older credit card accounts open to lengthen your average credit history age.",
        "If credit card utilization is persistently high, request an institutional credit limit enhancement rather than opening a new credit card."
    ]

    # Risk Factors
    risk_factors = []
    if missed > 0:
        risk_factors.append("Late payments remain on Indian bureau records for up to 36 months, though their impact diminishes with consecutive on-time records.")
    if utilization > 40:
        risk_factors.append("High revolving utilization can trigger sudden bureau score drops even if minimum amounts are paid on time.")
    if dti > 40:
        risk_factors.append("A high DTI ratio makes Indian banks hesitant to approve retail mortgage or vehicle loans.")
    if not risk_factors:
        risk_factors.append("Inadvertent billing disputes or delayed auto-debit triggers if account balances fall short on due dates.")

    # Goal Strategy
    goal_strategy = (
        f"Strategy for '{goal}': Keep your monthly EMI burden under ₹{income * 0.35:,.0f} (DTI < 35%), maintain zero missed payments, "
        f"and sustain credit utilization below 25%. Following this structured discipline typically demonstrates positive score momentum within 90-180 days."
    )

    summary = (
        f"Credit Health Assessment: Your current profile shows a credit score of {score} with a health status of '{health_status}'. "
        f"Your Debt-to-Income ratio is {dti}% and credit card utilization is {utilization}%. "
        + ("Addressing your missed payments and reducing card utilization will generate the fastest score improvement." if missed > 0 or utilization > 30 else "Your financial parameters are well-balanced; continuing consistent on-time payments will sustain your prime credit standing.")
    )

    return {
        "summary": summary,
        "health_status": health_status,
        "key_issues": key_issues,
        "action_plan": action_plan,
        "recommendations": recommendations,
        "risk_factors": risk_factors,
        "goal_strategy": goal_strategy,
        "educational_disclaimer": DISCLAIMER_TEXT
    }

async def generate_credit_advice(user_data: Dict[str, Any], custom_question: str = None) -> Dict[str, Any]:
    """
    Sends structured user financial metrics to Google Gemini API to generate personalized
    credit-health recommendations. If Gemini API key is missing or fails, gracefully returns
    an intelligent, rule-based Indian financial advisory response.
    """
    api_key = settings.GEMINI_API_KEY.strip() if settings.GEMINI_API_KEY else ""

    # If no API key is provided, use the expert rule-based Indian financial engine
    if not api_key or api_key == "your_gemini_api_key_here":
        logger.info("Gemini API key not configured. Using rule-based Indian credit advisory engine.")
        return _build_intelligent_fallback_advice(user_data)

    # Prompt Engineering for Gemini
    system_instruction = (
        "You are an expert Indian Credit Health and Financial Wellness Advisor called 'Credit Assistant'. "
        "You advise users in the Indian financial ecosystem (CIBIL score range 300-900, Indian Rupees INR/₹, "
        "DTI ratio, credit utilization, EMIs, Indian banking norms like RBI guidelines, NACH, NOC). "
        "Strict Rule: Always return output in valid JSON conforming EXACTLY to the requested schema. "
        "Do not invent fictitious banking rules or fake CIBIL policies. "
        "Always keep advice practical, educational, and encouraging."
    )

    prompt_content = f"""
Analyze the following Indian user's financial credit profile:
- Current CIBIL/Credit Score: {user_data.get('credit_score')} (Range 300-900)
- Gross Monthly Income: ₹{user_data.get('income', 0):,.2f}
- Monthly Living Expenses: ₹{user_data.get('expenses', 0):,.2f}
- Total Outstanding Debt: ₹{user_data.get('total_debt', 0):,.2f}
- Total Credit Limit: ₹{user_data.get('credit_limit', 0):,.2f}
- Current Credit Utilization: {user_data.get('credit_utilization', 0):.2f}% (Ideal Indian benchmark is <30%)
- Total Monthly EMI Payments: ₹{user_data.get('monthly_emi', 0):,.2f}
- Debt-to-Income (DTI) Ratio: {user_data.get('dti_ratio', 0):.2f}% (Safe Indian benchmark is <35%)
- Missed Payments Count: {user_data.get('missed_payments', 0)}
- Active Loans Count: {user_data.get('active_loans', 0)}
- User's Financial Goal: {user_data.get('financial_goal', 'Improve CIBIL Score')}
- Score Trajectory: {user_data.get('score_history_summary', 'Stable')}
{f'- Specific User Question: {custom_question}' if custom_question else ''}

Return a valid JSON object with the exact keys:
{{
  "summary": "Clear, concise 2-3 sentence overview of their financial health in Indian context",
  "health_status": "One of: 'Excellent', 'Good', 'Fair', or 'Needs Attention'",
  "key_issues": ["Specific bottleneck 1", "Specific bottleneck 2", "Specific bottleneck 3"],
  "action_plan": [
    "Step 1: Specific immediate action",
    "Step 2: Practical step",
    "Step 3: Concrete step",
    "Step 4: Medium term step",
    "Step 5: Long term habit"
  ],
  "recommendations": ["Recommendation 1", "Recommendation 2", "Recommendation 3"],
  "risk_factors": ["Risk factor 1", "Risk factor 2"],
  "goal_strategy": "Actionable pathway tailored to achieving their selected financial goal"
}}
"""

    gemini_endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{settings.GEMINI_MODEL}:generateContent?key={api_key}"
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": system_instruction + "\n\n" + prompt_content}
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.2,
            "responseMimeType": "application/json"
        }
    }

    try:
        async with httpx.AsyncClient(timeout=25.0) as client:
            response = await client.post(
                gemini_endpoint,
                headers={"Content-Type": "application/json"},
                json=payload
            )
            
            if response.status_code == 200:
                result_json = response.json()
                candidates = result_json.get("candidates", [])
                if candidates and "content" in candidates[0]:
                    text_response = candidates[0]["content"]["parts"][0]["text"]
                    cleaned_text = text_response.strip()
                    # Remove markdown code fences if present
                    if cleaned_text.startswith("```json"):
                        cleaned_text = cleaned_text[7:]
                    if cleaned_text.startswith("```"):
                        cleaned_text = cleaned_text[3:]
                    if cleaned_text.endswith("```"):
                        cleaned_text = cleaned_text[:-3]
                    cleaned_text = cleaned_text.strip()
                    
                    parsed = json.loads(cleaned_text)
                    parsed["educational_disclaimer"] = DISCLAIMER_TEXT
                    return parsed
            else:
                logger.warning(f"Gemini API returned status {response.status_code}: {response.text}")
    except Exception as e:
        logger.error(f"Error calling Gemini API: {e}")

    # Fallback to intelligent rule-based engine on any API failure
    return _build_intelligent_fallback_advice(user_data)
