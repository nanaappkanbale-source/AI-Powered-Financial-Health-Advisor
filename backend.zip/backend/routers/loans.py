from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from backend.database import get_db
from backend.models.user import User
from backend.models.loan import Loan
from backend.models.financial_profile import FinancialProfile
from backend.schemas.loan import LoanCreate, LoanUpdate, LoanOut
from backend.services.calculations import recalculate_profile_metrics
from backend.utils.security import get_current_user

router = APIRouter(prefix="/loans", tags=["Loans"])

def _sync_profile_from_loans(user_id: int, db: Session):
    """Syncs active loan balances, EMIs, and recalculates DTI in financial profile."""
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == user_id).first()
    if not profile:
        return

    active_loans = db.query(Loan).filter(Loan.user_id == user_id, Loan.status == "Active").all()
    
    total_active_outstanding = sum(l.outstanding_amount for l in active_loans)
    total_active_emi = sum(l.emi for l in active_loans)

    profile.total_debt = total_active_outstanding
    profile.monthly_emi = total_active_emi
    profile.active_loans = len(active_loans)

    # Recalculate DTI and Utilization
    dti, util = recalculate_profile_metrics(
        income=profile.income,
        expenses=profile.expenses,
        credit_limit=profile.credit_limit,
        outstanding_credit_or_debt=profile.total_debt if profile.total_debt <= profile.credit_limit else (profile.credit_limit * 0.35 if profile.credit_limit > 0 else 0.0),
        monthly_emi=profile.monthly_emi
    )
    profile.dti_ratio = dti
    profile.credit_utilization = util
    profile.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(profile)

@router.get("", response_model=List[LoanOut])
def get_user_loans(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Returns all loans associated with the authenticated user."""
    return db.query(Loan).filter(Loan.user_id == current_user.id).order_by(Loan.id.desc()).all()

@router.post("", response_model=LoanOut, status_code=status.HTTP_201_CREATED)
def create_loan(
    loan_in: LoanCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Creates a new loan and automatically recalculates total debt, monthly EMI, and DTI.
    """
    new_loan = Loan(
        user_id=current_user.id,
        loan_name=loan_in.loan_name.strip(),
        principal_amount=loan_in.principal_amount,
        outstanding_amount=loan_in.outstanding_amount,
        emi=loan_in.emi,
        interest_rate=loan_in.interest_rate,
        start_date=loan_in.start_date,
        end_date=loan_in.end_date,
        status=loan_in.status
    )
    db.add(new_loan)
    db.commit()
    db.refresh(new_loan)

    _sync_profile_from_loans(current_user.id, db)
    return new_loan

@router.put("/{loan_id}", response_model=LoanOut)
def update_loan(
    loan_id: int,
    loan_update: LoanUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Updates an existing loan (e.g. mark Closed or reduce outstanding balance)
    and updates total debt and DTI.
    """
    loan = db.query(Loan).filter(Loan.id == loan_id, Loan.user_id == current_user.id).first()
    if not loan:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Loan not found.")

    if loan_update.loan_name is not None:
        loan.loan_name = loan_update.loan_name.strip()
    if loan_update.principal_amount is not None:
        loan.principal_amount = loan_update.principal_amount
    if loan_update.outstanding_amount is not None:
        loan.outstanding_amount = loan_update.outstanding_amount
    if loan_update.emi is not None:
        loan.emi = loan_update.emi
    if loan_update.interest_rate is not None:
        loan.interest_rate = loan_update.interest_rate
    if loan_update.start_date is not None:
        loan.start_date = loan_update.start_date
    if loan_update.end_date is not None:
        loan.end_date = loan_update.end_date
    if loan_update.status is not None:
        loan.status = loan_update.status
        if loan.status == "Closed":
            loan.outstanding_amount = 0.0

    db.commit()
    db.refresh(loan)

    _sync_profile_from_loans(current_user.id, db)
    return loan

@router.delete("/{loan_id}")
def delete_loan(
    loan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Deletes a loan record and recalculates financial profile metrics."""
    loan = db.query(Loan).filter(Loan.id == loan_id, Loan.user_id == current_user.id).first()
    if not loan:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Loan not found.")
    
    db.delete(loan)
    db.commit()

    _sync_profile_from_loans(current_user.id, db)
    return {"message": "Loan deleted successfully."}
