from backend.routers.auth import router as auth_router
from backend.routers.users import router as users_router
from backend.routers.financial_profile import router as financial_profile_router
from backend.routers.credit_score import router as credit_score_router
from backend.routers.loans import router as loans_router
from backend.routers.dashboard import router as dashboard_router
from backend.routers.ai import router as ai_router
from backend.routers.demo import router as demo_router

__all__ = [
    "auth_router",
    "users_router",
    "financial_profile_router",
    "credit_score_router",
    "loans_router",
    "dashboard_router",
    "ai_router",
    "demo_router"
]
