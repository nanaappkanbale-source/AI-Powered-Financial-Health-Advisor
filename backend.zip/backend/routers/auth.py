from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.database import get_db
from backend.models.user import User
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.schemas.auth import UserRegister, UserLogin, Token, UserSummary
from backend.utils.security import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(user_in: UserRegister, db: Session = Depends(get_db)):
    """Registers a new user, hashes password, creates a default financial profile, and returns JWT."""
    # Check if email already registered
    existing_user = db.query(User).filter(User.email == user_in.email.lower().strip()).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists. Please log in."
        )

    # Hash password using bcrypt
    hashed = hash_password(user_in.password)

    new_user = User(
        name=user_in.name.strip(),
        email=user_in.email.lower().strip(),
        password_hash=hashed
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Create default starter financial profile
    profile = FinancialProfile(
        user_id=new_user.id,
        income=0.0,
        expenses=0.0,
        credit_score=650,
        total_debt=0.0,
        credit_limit=0.0,
        credit_utilization=0.0,
        dti_ratio=0.0,
        missed_payments=0,
        active_loans=0,
        monthly_emi=0.0,
        financial_goal="Improve CIBIL Score to 750+"
    )
    db.add(profile)

    # Record initial score entry
    initial_score = CreditScoreHistory(
        user_id=new_user.id,
        credit_score=650,
        score_change=0
    )
    db.add(initial_score)
    db.commit()

    token = create_access_token(subject=str(new_user.id))
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": UserSummary.model_validate(new_user)
    }

@router.post("/login", response_model=Token)
def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Authenticates user with email and password, returning JWT token."""
    user = db.query(User).filter(User.email == credentials.email.lower().strip()).first()
    if not user or not verify_password(credentials.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password. Please check your credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    token = create_access_token(subject=str(user.id))
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": UserSummary.model_validate(user)
    }

@router.post("/logout")
def logout():
    """Client-side token invalidation confirmation."""
    return {"message": "Logged out successfully"}
