from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from backend.database import get_db
from backend.models.user import User
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.schemas.dashboard import (
    DashboardData,
    DashboardCards,
    HealthIndicator,
    ScoreProgress
)
from backend.services.health_assessment import assess_credit_health
from backend.utils.security import get_current_user

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("", response_model=DashboardData)
def get_dashboard_data(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns aggregated metrics, health assessment, and formatted chart datasets for the dashboard.
    """
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == current_user.id).first()
    has_profile = profile is not None and (profile.income > 0 or profile.total_debt > 0 or profile.credit_limit > 0)

    # Defaults if profile is fresh
    credit_score = profile.credit_score if profile else 650
    dti_ratio = profile.dti_ratio if profile else 0.0
    credit_utilization = profile.credit_utilization if profile else 0.0
    outstanding_debt = profile.total_debt if profile else 0.0
    monthly_income = profile.income if profile else 0.0
    monthly_expenses = profile.expenses if profile else 0.0
    monthly_emi = profile.monthly_emi if profile else 0.0
    active_loans_count = profile.active_loans if profile else 0
    credit_limit = profile.credit_limit if profile else 0.0
    missed_payments = profile.missed_payments if profile else 0

    # Fetch credit score history
    history_records = db.query(CreditScoreHistory)\
        .filter(CreditScoreHistory.user_id == current_user.id)\
        .order_by(CreditScoreHistory.recorded_at.asc())\
        .all()

    scores = [h.credit_score for h in history_records] if history_records else [credit_score]
    previous_score = history_records[-2].credit_score if len(history_records) >= 2 else None
    latest_score_change = history_records[-1].score_change if history_records else 0
    overall_improvement = scores[-1] - scores[0] if len(scores) > 1 else 0

    # Health Assessment
    health_data = assess_credit_health(
        credit_score=credit_score,
        dti_ratio=dti_ratio,
        credit_utilization=credit_utilization,
        missed_payments=missed_payments,
        income=monthly_income,
        expenses=monthly_expenses,
        score_change=latest_score_change
    )

    # 1. Line Chart Data: Credit Score History
    score_history_chart: List[Dict[str, Any]] = []
    if history_records:
        for rec in history_records:
            score_history_chart.append({
                "date": rec.recorded_at.strftime("%d-%b-%Y"),
                "shortDate": rec.recorded_at.strftime("%d/%m"),
                "credit_score": rec.credit_score,
                "change": rec.score_change
            })
    else:
        score_history_chart.append({
            "date": "Today",
            "shortDate": "Today",
            "credit_score": credit_score,
            "change": 0
        })

    # 2. Donut/Pie Chart Data: Credit Utilization (Used vs Available)
    used_credit = (credit_limit * (credit_utilization / 100.0)) if credit_limit > 0 else 0.0
    available_credit = max(0.0, credit_limit - used_credit)
    credit_utilization_chart = [
        {"name": "Used Credit", "value": round(used_credit, 2), "color": "#ef4444" if credit_utilization > 50 else ("#f59e0b" if credit_utilization > 30 else "#0284c7")},
        {"name": "Available Credit", "value": round(available_credit, 2), "color": "#10b981"}
    ]

    # 3. Bar Chart Data: Financial Overview (Income vs Expenses vs EMI)
    financial_overview_chart = [
        {"category": "Monthly Income", "amount": monthly_income, "color": "#10b981"},
        {"category": "Living Expenses", "amount": monthly_expenses, "color": "#6366f1"},
        {"category": "Debt EMIs", "amount": monthly_emi, "color": "#f43f5e"},
        {"category": "Net Savings", "amount": max(0.0, monthly_income - monthly_expenses - monthly_emi), "color": "#0ea5e9"}
    ]

    return DashboardData(
        user_name=current_user.name,
        user_email=current_user.email,
        has_profile=has_profile,
        profile=profile,
        cards=DashboardCards(
            credit_score=credit_score,
            health_status=health_data["status"],
            dti_ratio=dti_ratio,
            credit_utilization=credit_utilization,
            outstanding_debt=outstanding_debt,
            monthly_income=monthly_income,
            monthly_expenses=monthly_expenses,
            monthly_emi=monthly_emi,
            active_loans_count=active_loans_count
        ),
        health_indicator=HealthIndicator(**health_data),
        score_progress=ScoreProgress(
            current_score=credit_score,
            previous_score=previous_score,
            score_change=latest_score_change,
            highest_score=max(scores),
            lowest_score=min(scores),
            overall_improvement=overall_improvement
        ),
        score_history_chart=score_history_chart,
        credit_utilization_chart=credit_utilization_chart,
        financial_overview_chart=financial_overview_chart
    )
