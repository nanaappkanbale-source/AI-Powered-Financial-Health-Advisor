from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.database import get_db
from backend.models.user import User
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.schemas.financial_profile import (
    FinancialProfileCreate,
    FinancialProfileUpdate,
    FinancialProfileOut
)
from backend.services.calculations import recalculate_profile_metrics
from backend.utils.security import get_current_user

router = APIRouter(prefix="/financial-profile", tags=["Financial Profile"])

@router.get("", response_model=FinancialProfileOut)
def get_financial_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieves the authenticated user's financial profile."""
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == current_user.id).first()
    if not profile:
        # Create a blank initialized profile
        profile = FinancialProfile(
            user_id=current_user.id,
            income=0.0,
            expenses=0.0,
            credit_score=650,
            total_debt=0.0,
            credit_limit=0.0,
            credit_utilization=0.0,
            dti_ratio=0.0,
            missed_payments=0,
            active_loans=0,
            monthly_emi=0.0,
            financial_goal="Improve CIBIL Score to 750+"
        )
        db.add(profile)
        db.commit()
        db.refresh(profile)
    return profile

@router.post("", response_model=FinancialProfileOut)
@router.put("", response_model=FinancialProfileOut)
def save_or_update_financial_profile(
    profile_data: FinancialProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Creates or updates the financial profile.
    Automatically recalculates DTI and Credit Utilization.
    Tracks credit score history if score changes.
    """
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == current_user.id).first()
    if not profile:
        profile = FinancialProfile(user_id=current_user.id)
        db.add(profile)

    old_score = profile.credit_score or 650

    # Apply provided values
    if profile_data.income is not None:
        profile.income = profile_data.income
    if profile_data.expenses is not None:
        profile.expenses = profile_data.expenses
    if profile_data.total_debt is not None:
        profile.total_debt = profile_data.total_debt
    if profile_data.credit_limit is not None:
        profile.credit_limit = profile_data.credit_limit
    if profile_data.monthly_emi is not None:
        profile.monthly_emi = profile_data.monthly_emi
    if profile_data.missed_payments is not None:
        profile.missed_payments = profile_data.missed_payments
    if profile_data.active_loans is not None:
        profile.active_loans = profile_data.active_loans
    if profile_data.financial_goal is not None:
        profile.financial_goal = profile_data.financial_goal.strip()

    # Automatic calculations
    # Outstanding card balance or debt for utilization:
    # If debt is available, estimate revolving portion or direct limit ratio
    revolving_or_debt = profile.total_debt if profile.total_debt <= profile.credit_limit else (profile.credit_limit * 0.35 if profile.credit_limit > 0 else 0.0)
    dti, util = recalculate_profile_metrics(
        income=profile.income,
        expenses=profile.expenses,
        credit_limit=profile.credit_limit,
        outstanding_credit_or_debt=revolving_or_debt,
        monthly_emi=profile.monthly_emi
    )
    profile.dti_ratio = dti
    profile.credit_utilization = util

    # Track credit score update
    if profile_data.credit_score is not None and profile_data.credit_score != old_score:
        new_score = profile_data.credit_score
        score_diff = new_score - old_score
        profile.credit_score = new_score
        
        # Save to CreditScoreHistory
        history_entry = CreditScoreHistory(
            user_id=current_user.id,
            credit_score=new_score,
            score_change=score_diff,
            recorded_at=datetime.now(timezone.utc)
        )
        db.add(history_entry)

    profile.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(profile)
    return profile
