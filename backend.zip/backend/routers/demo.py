from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import get_db
from backend.models.user import User
from backend.services.demo_data import load_demo_data_for_user, clear_user_demo_data
from backend.utils.security import get_current_user

router = APIRouter(prefix="/demo", tags=["Demo Data"])

@router.post("/load")
def populate_demo_data(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Populates full realistic Indian demo financial profile, loans, score history,
    and AI recommendations for the authenticated user for easy evaluation and viva demonstration.
    """
    load_demo_data_for_user(current_user.id, db)
    return {"message": "Demo data populated successfully! Dashboard and charts have been refreshed."}

@router.post("/clear")
def clear_demo_data(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Clears financial demo data and resets profile to initial state."""
    clear_user_demo_data(current_user.id, db)
    return {"message": "User financial data reset successfully."}
