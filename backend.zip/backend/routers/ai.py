import json
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from backend.database import get_db
from backend.models.user import User
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.models.loan import Loan
from backend.models.ai_recommendation import AIRecommendation
from backend.schemas.ai import AIAdviceRequest, AIStructuredAdvice, AIRecommendationOut
from backend.ai.gemini_service import generate_credit_advice
from backend.utils.security import get_current_user

router = APIRouter(prefix="/ai", tags=["AI Financial Advisor"])

@router.post("/advice", response_model=AIStructuredAdvice)
async def analyze_credit_health(
    request: AIAdviceRequest = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Sends structured user financial metrics to Gemini AI (or resilient Indian credit advisor engine)
    and returns a 5-step action plan, key issues, recommendations, and goal strategy.
    Stores the consultation in the database history.
    """
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Please set up your financial profile before requesting AI advice."
        )

    # Score trajectory context
    histories = db.query(CreditScoreHistory)\
        .filter(CreditScoreHistory.user_id == current_user.id)\
        .order_by(CreditScoreHistory.recorded_at.desc())\
        .limit(3)\
        .all()
    
    score_history_summary = "Stable"
    if len(histories) >= 2:
        diff = histories[0].credit_score - histories[1].credit_score
        if diff > 0:
            score_history_summary = f"Improving (+{diff} points recently)"
        elif diff < 0:
            score_history_summary = f"Declining ({diff} points recently)"

    # Prepare structured user financial payload
    user_data = {
        "credit_score": profile.credit_score,
        "income": profile.income,
        "expenses": profile.expenses,
        "total_debt": profile.total_debt,
        "credit_limit": profile.credit_limit,
        "credit_utilization": profile.credit_utilization,
        "dti_ratio": profile.dti_ratio,
        "missed_payments": profile.missed_payments,
        "active_loans": profile.active_loans,
        "monthly_emi": profile.monthly_emi,
        "financial_goal": profile.financial_goal,
        "score_history_summary": score_history_summary
    }

    custom_question = request.custom_question if request else None
    ai_result = await generate_credit_advice(user_data=user_data, custom_question=custom_question)

    # Persist consultation to database
    recommendation_record = AIRecommendation(
        user_id=current_user.id,
        summary=ai_result.get("summary", ""),
        health_status=ai_result.get("health_status", "Fair"),
        recommendations=json.dumps(ai_result),
        created_at=datetime.now(timezone.utc)
    )
    db.add(recommendation_record)
    db.commit()

    return AIStructuredAdvice(**ai_result)

@router.get("/recommendations", response_model=List[AIRecommendationOut])
def get_recommendation_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Returns past AI consultation logs and action plans."""
    records = db.query(AIRecommendation)\
        .filter(AIRecommendation.user_id == current_user.id)\
        .order_by(AIRecommendation.created_at.desc())\
        .all()

    results = []
    for rec in records:
        try:
            parsed = json.loads(rec.recommendations)
        except Exception:
            parsed = {"summary": rec.summary}
        
        results.append(AIRecommendationOut(
            id=rec.id,
            user_id=rec.user_id,
            summary=rec.summary,
            health_status=rec.health_status,
            recommendations=parsed,
            created_at=rec.created_at
        ))
    return results
