from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from backend.database import get_db
from backend.models.user import User
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.schemas.credit_score import (
    CreditScoreCreate,
    CreditScoreHistoryOut,
    CreditScoreOverviewOut
)
from backend.utils.security import get_current_user

router = APIRouter(prefix="/credit-score", tags=["Credit Score Tracking"])

@router.get("/history", response_model=CreditScoreOverviewOut)
def get_credit_score_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns historical credit score timeline along with calculated overview metrics:
    Current score, Previous score, Score change, Highest score, Lowest score, and Overall improvement.
    """
    histories = db.query(CreditScoreHistory)\
        .filter(CreditScoreHistory.user_id == current_user.id)\
        .order_by(CreditScoreHistory.recorded_at.asc())\
        .all()

    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == current_user.id).first()
    current_score = profile.credit_score if profile else 650

    if not histories:
        # If no history exists, synthesize baseline entry
        return CreditScoreOverviewOut(
            current_score=current_score,
            previous_score=None,
            score_change=0,
            highest_score=current_score,
            lowest_score=current_score,
            overall_improvement=0,
            history=[]
        )

    scores = [h.credit_score for h in histories]
    highest_score = max(scores)
    lowest_score = min(scores)
    
    previous_score = histories[-2].credit_score if len(histories) >= 2 else None
    latest_change = histories[-1].score_change if histories else 0
    overall_improvement = scores[-1] - scores[0] if len(scores) > 1 else 0

    return CreditScoreOverviewOut(
        current_score=scores[-1],
        previous_score=previous_score,
        score_change=latest_change,
        highest_score=highest_score,
        lowest_score=lowest_score,
        overall_improvement=overall_improvement,
        history=histories
    )

@router.post("", response_model=CreditScoreOverviewOut, status_code=status.HTTP_201_CREATED)
def record_credit_score(
    score_in: CreditScoreCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Records a new credit score:
    - Stores new score & timestamp
    - Compares with previous score
    - Calculates change
    - Updates user financial profile
    - Returns updated score statistics
    """
    last_record = db.query(CreditScoreHistory)\
        .filter(CreditScoreHistory.user_id == current_user.id)\
        .order_by(CreditScoreHistory.recorded_at.desc())\
        .first()

    previous_score = last_record.credit_score if last_record else None
    change = (score_in.credit_score - previous_score) if previous_score is not None else 0

    new_record = CreditScoreHistory(
        user_id=current_user.id,
        credit_score=score_in.credit_score,
        score_change=change,
        recorded_at=datetime.now(timezone.utc)
    )
    db.add(new_record)

    # Sync with FinancialProfile
    profile = db.query(FinancialProfile).filter(FinancialProfile.user_id == current_user.id).first()
    if profile:
        profile.credit_score = score_in.credit_score
        profile.updated_at = datetime.now(timezone.utc)

    db.commit()

    return get_credit_score_history(current_user=current_user, db=db)
