from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Any, Dict

class AIAdviceRequest(BaseModel):
    custom_question: Optional[str] = Field(None, description="Optional specific query or concern from the user")

class AIStructuredAdvice(BaseModel):
    summary: str
    health_status: str
    key_issues: List[str]
    action_plan: List[str] # 5-step action plan
    recommendations: List[str]
    risk_factors: List[str]
    goal_strategy: str
    educational_disclaimer: str = (
        "Educational Notice: This AI analysis is generated for educational and informational purposes "
        "only and does not constitute formal banking, credit rating, or certified financial advice. "
        "Credit scores are subject to official bureau methodologies (such as TransUnion CIBIL, Experian, Equifax, CRIF High Mark)."
    )

class AIRecommendationOut(BaseModel):
    id: int
    user_id: int
    summary: str
    health_status: str
    recommendations: Dict[str, Any] # parsed JSON structure
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
