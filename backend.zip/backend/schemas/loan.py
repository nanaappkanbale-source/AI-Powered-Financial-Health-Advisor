from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional

class LoanBase(BaseModel):
    loan_name: str = Field(..., min_length=2, max_length=150, description="e.g. HDFC Home Loan, Axis Car Loan")
    principal_amount: float = Field(..., gt=0, description="Total borrowed amount in ₹")
    outstanding_amount: float = Field(..., ge=0, description="Current remaining balance in ₹")
    emi: float = Field(..., ge=0, description="Monthly EMI in ₹")
    interest_rate: float = Field(10.5, ge=0, le=100, description="Annual interest rate in %")
    start_date: Optional[str] = Field(None, description="Start date (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="Expected end date (YYYY-MM-DD)")
    status: str = Field("Active", description="'Active' or 'Closed'")

class LoanCreate(LoanBase):
    pass

class LoanUpdate(BaseModel):
    loan_name: Optional[str] = None
    principal_amount: Optional[float] = None
    outstanding_amount: Optional[float] = None
    emi: Optional[float] = None
    interest_rate: Optional[float] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    status: Optional[str] = None

class LoanOut(LoanBase):
    id: int
    user_id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
