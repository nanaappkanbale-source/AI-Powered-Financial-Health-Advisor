from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional

class FinancialProfileBase(BaseModel):
    income: float = Field(0.0, ge=0, description="Monthly gross income in INR (₹)")
    expenses: float = Field(0.0, ge=0, description="Monthly living expenses in INR (₹)")
    credit_score: int = Field(650, ge=300, le=900, description="Current CIBIL/Credit score (300-900)")
    total_debt: float = Field(0.0, ge=0, description="Total outstanding debt in INR (₹)")
    credit_limit: float = Field(0.0, ge=0, description="Total credit limit across cards in INR (₹)")
    missed_payments: int = Field(0, ge=0, description="Number of missed/delayed payments in last 24 months")
    active_loans: int = Field(0, ge=0, description="Number of currently active loans")
    monthly_emi: float = Field(0.0, ge=0, description="Total monthly EMI in INR (₹)")
    financial_goal: str = Field("Improve CIBIL Score to 750+", description="Target financial milestone")

class FinancialProfileCreate(FinancialProfileBase):
    pass

class FinancialProfileUpdate(BaseModel):
    income: Optional[float] = Field(None, ge=0)
    expenses: Optional[float] = Field(None, ge=0)
    credit_score: Optional[int] = Field(None, ge=300, le=900)
    total_debt: Optional[float] = Field(None, ge=0)
    credit_limit: Optional[float] = Field(None, ge=0)
    missed_payments: Optional[int] = Field(None, ge=0)
    active_loans: Optional[int] = Field(None, ge=0)
    monthly_emi: Optional[float] = Field(None, ge=0)
    financial_goal: Optional[str] = None

class FinancialProfileOut(FinancialProfileBase):
    id: int
    user_id: int
    credit_utilization: float # In percent %
    dti_ratio: float          # In percent %
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
