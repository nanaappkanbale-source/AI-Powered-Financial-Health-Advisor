from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from backend.schemas.financial_profile import FinancialProfileOut
from backend.schemas.credit_score import CreditScoreHistoryOut

class HealthIndicator(BaseModel):
    status: str # "Excellent", "Good", "Fair", "Needs Attention"
    color: str # "emerald", "blue", "amber", "rose"
    score: int
    summary: str
    reasons: List[str]
    disclaimer: str = "Internal application assessment based on standard Indian credit benchmarks. Not an official bureau rating."

class DashboardCards(BaseModel):
    credit_score: int
    health_status: str
    dti_ratio: float
    credit_utilization: float
    outstanding_debt: float
    monthly_income: float
    monthly_expenses: float
    monthly_emi: float
    active_loans_count: int

class ScoreProgress(BaseModel):
    current_score: int
    previous_score: Optional[int]
    score_change: int
    highest_score: int
    lowest_score: int
    overall_improvement: int

class ChartPoint(BaseModel):
    name: str
    value: float
    secondary: Optional[float] = None
    label: Optional[str] = None

class DashboardData(BaseModel):
    user_name: str
    user_email: str
    has_profile: bool
    profile: Optional[FinancialProfileOut] = None
    cards: DashboardCards
    health_indicator: HealthIndicator
    score_progress: ScoreProgress
    score_history_chart: List[Dict[str, Any]]
    credit_utilization_chart: List[Dict[str, Any]]
    financial_overview_chart: List[Dict[str, Any]]
