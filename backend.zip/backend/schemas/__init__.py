from backend.schemas.auth import UserRegister, UserLogin, Token, UserSummary
from backend.schemas.user import UserOut, UserUpdate, PasswordChange
from backend.schemas.financial_profile import FinancialProfileBase, FinancialProfileCreate, FinancialProfileUpdate, FinancialProfileOut
from backend.schemas.credit_score import CreditScoreCreate, CreditScoreHistoryOut, CreditScoreOverviewOut
from backend.schemas.loan import LoanBase, LoanCreate, LoanUpdate, LoanOut
from backend.schemas.ai import AIAdviceRequest, AIStructuredAdvice, AIRecommendationOut
from backend.schemas.dashboard import DashboardData, DashboardCards, HealthIndicator, ScoreProgress

__all__ = [
    "UserRegister", "UserLogin", "Token", "UserSummary",
    "UserOut", "UserUpdate", "PasswordChange",
    "FinancialProfileBase", "FinancialProfileCreate", "FinancialProfileUpdate", "FinancialProfileOut",
    "CreditScoreCreate", "CreditScoreHistoryOut", "CreditScoreOverviewOut",
    "LoanBase", "LoanCreate", "LoanUpdate", "LoanOut",
    "AIAdviceRequest", "AIStructuredAdvice", "AIRecommendationOut",
    "DashboardData", "DashboardCards", "HealthIndicator", "ScoreProgress",
]
