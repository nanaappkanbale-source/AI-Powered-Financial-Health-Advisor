from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional

class CreditScoreCreate(BaseModel):
    credit_score: int = Field(..., ge=300, le=900, description="New CIBIL/Credit score between 300 and 900")

class CreditScoreHistoryOut(BaseModel):
    id: int
    user_id: int
    credit_score: int
    score_change: int
    recorded_at: datetime

    model_config = ConfigDict(from_attributes=True)

class CreditScoreOverviewOut(BaseModel):
    current_score: int
    previous_score: Optional[int] = None
    score_change: int = 0
    highest_score: int
    lowest_score: int
    overall_improvement: int = 0
    history: List[CreditScoreHistoryOut]
