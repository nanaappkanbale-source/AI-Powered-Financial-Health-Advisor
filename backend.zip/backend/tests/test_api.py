import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker

# Import all models to ensure metadata is populated
import backend.models
from backend.database import Base, get_db
from backend.main import app
from backend.services.calculations import calculate_dti, calculate_credit_utilization

# Setup in-memory SQLite database with StaticPool so all connections share the same memory DB
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create tables in the shared memory DB
Base.metadata.create_all(bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

def test_unit_calculations():
    """Tests DTI and Credit Utilization formulas."""
    dti = calculate_dti(monthly_debt_payments=10000, gross_monthly_income=50000)
    assert dti == 20.0

    util = calculate_credit_utilization(outstanding_credit=30000, total_credit_limit=100000)
    assert util == 30.0

    assert calculate_dti(1000, 0) == 0.0
    assert calculate_credit_utilization(500, 0) == 0.0

def test_user_registration_and_login():
    """Tests user registration, JWT generation, and login."""
    reg_payload = {
        "name": "Aarav Patel",
        "email": "aarav.patel@example.com",
        "password": "Password123!",
        "confirm_password": "Password123!"
    }
    response = client.post("/api/auth/register", json=reg_payload)
    assert response.status_code == 201
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == "aarav.patel@example.com"

    # Duplicate registration should fail
    dup_response = client.post("/api/auth/register", json=reg_payload)
    assert dup_response.status_code == 400

    # Login
    login_payload = {
        "email": "aarav.patel@example.com",
        "password": "Password123!"
    }
    login_resp = client.post("/api/auth/login", json=login_payload)
    assert login_resp.status_code == 200
    login_data = login_resp.json()
    assert "access_token" in login_data
    token = login_data["access_token"]

    # Verify protected route /users/me
    headers = {"Authorization": f"Bearer {token}"}
    me_resp = client.get("/api/users/me", headers=headers)
    assert me_resp.status_code == 200
    assert me_resp.json()["name"] == "Aarav Patel"

def test_financial_profile_and_recalculations():
    """Tests updating financial profile, DTI and Utilization calculation."""
    login_resp = client.post("/api/auth/login", json={
        "email": "aarav.patel@example.com",
        "password": "Password123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    profile_payload = {
        "income": 60000,
        "expenses": 25000,
        "credit_score": 710,
        "total_debt": 30000,
        "credit_limit": 100000,
        "monthly_emi": 12000,
        "missed_payments": 0,
        "active_loans": 1,
        "financial_goal": "Buy a car with prime interest rate"
    }
    update_resp = client.put("/api/financial-profile", json=profile_payload, headers=headers)
    assert update_resp.status_code == 200
    p_data = update_resp.json()
    assert p_data["dti_ratio"] == 20.0
    assert p_data["credit_utilization"] == 30.0
    assert p_data["credit_score"] == 710

def test_credit_score_history_and_overview():
    """Tests adding new credit scores and tracking difference."""
    login_resp = client.post("/api/auth/login", json={
        "email": "aarav.patel@example.com",
        "password": "Password123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    post_score = client.post("/api/credit-score", json={"credit_score": 740}, headers=headers)
    assert post_score.status_code == 201
    score_overview = post_score.json()
    assert score_overview["current_score"] == 740
    assert score_overview["score_change"] == 30
    assert score_overview["highest_score"] >= 740

def test_loans_creation_and_auto_sync():
    """Tests loan creation and auto-sync with financial profile."""
    login_resp = client.post("/api/auth/login", json={
        "email": "aarav.patel@example.com",
        "password": "Password123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    loan_payload = {
        "loan_name": "Axis Bank Two Wheeler Loan",
        "principal_amount": 90000,
        "outstanding_amount": 75000,
        "emi": 3200,
        "interest_rate": 10.5,
        "status": "Active"
    }
    loan_resp = client.post("/api/loans", json=loan_payload, headers=headers)
    assert loan_resp.status_code == 201
    loan_data = loan_resp.json()
    loan_id = loan_data["id"]

    list_resp = client.get("/api/loans", headers=headers)
    assert list_resp.status_code == 200
    assert any(l["id"] == loan_id for l in list_resp.json())

    update_loan = client.put(f"/api/loans/{loan_id}", json={"status": "Closed"}, headers=headers)
    assert update_loan.status_code == 200
    assert update_loan.json()["status"] == "Closed"
    assert update_loan.json()["outstanding_amount"] == 0.0

def test_dashboard_api():
    """Tests consolidated dashboard endpoint."""
    login_resp = client.post("/api/auth/login", json={
        "email": "aarav.patel@example.com",
        "password": "Password123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    dash_resp = client.get("/api/dashboard", headers=headers)
    assert dash_resp.status_code == 200
    dash_data = dash_resp.json()
    assert "cards" in dash_data
    assert "health_indicator" in dash_data
    assert "score_history_chart" in dash_data
    assert "credit_utilization_chart" in dash_data
    assert "financial_overview_chart" in dash_data
    assert dash_data["health_indicator"]["status"] in ["Excellent", "Good", "Fair", "Needs Attention"]

def test_ai_advice_endpoint():
    """Tests AI advice endpoint with resilient fallback/mock."""
    login_resp = client.post("/api/auth/login", json={
        "email": "aarav.patel@example.com",
        "password": "Password123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    ai_resp = client.post("/api/ai/advice", json={"custom_question": "How to reach 780 CIBIL?"}, headers=headers)
    assert ai_resp.status_code == 200
    ai_data = ai_resp.json()
    assert "summary" in ai_data
    assert "action_plan" in ai_data
    assert len(ai_data["action_plan"]) >= 3
    assert "educational_disclaimer" in ai_data

    history_resp = client.get("/api/ai/recommendations", headers=headers)
    assert history_resp.status_code == 200
    assert len(history_resp.json()) >= 1
