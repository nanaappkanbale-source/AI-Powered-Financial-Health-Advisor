import sys
import httpx

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

BASE_URL = "http://127.0.0.1:8000/api"

def run_e2e_verification():
    print("=" * 60)
    print("Starting End-to-End Functional Verification for Credit Assistant")
    print("=" * 60)

    client = httpx.Client(timeout=15.0)

    # 1. Health & Status
    health = client.get("http://127.0.0.1:8000/health")
    assert health.status_code == 200, f"Health check failed: {health.status_code}"
    print("PASS: 1. Health check endpoint (200 OK)")

    # 2. Registration
    test_user_payload = {
        "name": "Pooja Hegde",
        "email": "pooja.hegde@example.com",
        "password": "SecurePassword123!",
        "confirm_password": "SecurePassword123!"
    }
    reg_resp = client.post(f"{BASE_URL}/auth/register", json=test_user_payload)
    if reg_resp.status_code == 400 and "already exists" in reg_resp.text:
        print("User already registered, proceeding to login...")
    else:
        assert reg_resp.status_code == 201, f"Registration failed: {reg_resp.text}"
        print("PASS: 2. User registration with bcrypt hashing")

    # 3. Login
    login_resp = client.post(f"{BASE_URL}/auth/login", json={
        "email": "pooja.hegde@example.com",
        "password": "SecurePassword123!"
    })
    assert login_resp.status_code == 200, f"Login failed: {login_resp.text}"
    token_data = login_resp.json()
    token = token_data["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print(f"PASS: 3. User login and JWT issue (Token: {token[:20]}...)")

    # 4. Protected Route Check (/users/me)
    # Without token
    unauth = client.get(f"{BASE_URL}/users/me")
    assert unauth.status_code == 401, f"Expected 401 for unauthenticated request, got {unauth.status_code}"
    # With token
    auth_me = client.get(f"{BASE_URL}/users/me", headers=headers)
    assert auth_me.status_code == 200, f"Expected 200 with token, got {auth_me.status_code}"
    assert auth_me.json()["email"] == "pooja.hegde@example.com"
    print("PASS: 4. Protected routes enforcement (401 without token, 200 with token)")

    # 5. Financial Profile Management & Automated Calculations
    profile_payload = {
        "income": 75000.0,
        "expenses": 32000.0,
        "credit_score": 690,
        "total_debt": 35000.0,
        "credit_limit": 100000.0,
        "monthly_emi": 15000.0,
        "missed_payments": 0,
        "active_loans": 1,
        "financial_goal": "Reach 770+ for SBI Home Loan sanction"
    }
    prof_resp = client.put(f"{BASE_URL}/financial-profile", json=profile_payload, headers=headers)
    assert prof_resp.status_code == 200, f"Profile update failed: {prof_resp.text}"
    p_data = prof_resp.json()

    # Verify DTI: (15,000 / 75,000) * 100 = 20.0%
    assert p_data["dti_ratio"] == 20.0, f"Expected DTI 20.0%, got {p_data['dti_ratio']}%"
    print(f"PASS: 5. Automated DTI calculation verified: {p_data['dti_ratio']}%")

    # Verify Credit Utilization: (35,000 / 100,000) * 100 = 35.0%
    assert p_data["credit_utilization"] == 35.0, f"Expected utilization 35.0%, got {p_data['credit_utilization']}%"
    print(f"PASS: 6. Automated Credit Utilization calculation verified: {p_data['credit_utilization']}%")

    # 6. Credit Score Tracking
    score_resp = client.post(f"{BASE_URL}/credit-score", json={"credit_score": 725}, headers=headers)
    assert score_resp.status_code == 201, f"Credit score record failed: {score_resp.text}"
    score_data = score_resp.json()
    assert score_data["current_score"] == 725
    assert score_data["score_change"] == 35  # from 690 to 725 = +35
    print(f"PASS: 7. Credit score history tracking (+{score_data['score_change']} points improvement)")

    # 7. Loan Creation & Profile Auto-Sync
    loan_payload = {
        "loan_name": "Kotak Mahindra Personal Loan",
        "principal_amount": 100000.0,
        "outstanding_amount": 80000.0,
        "emi": 4500.0,
        "interest_rate": 11.2,
        "start_date": "2026-01-10",
        "end_date": "2028-01-10",
        "status": "Active"
    }
    loan_resp = client.post(f"{BASE_URL}/loans", json=loan_payload, headers=headers)
    assert loan_resp.status_code == 201, f"Loan creation failed: {loan_resp.text}"
    loan_id = loan_resp.json()["id"]
    print("PASS: 8. Loan creation and automatic debt synchronization")

    # 8. Mark Loan as Paid / Closed
    update_loan = client.put(f"{BASE_URL}/loans/{loan_id}", json={"status": "Closed"}, headers=headers)
    assert update_loan.status_code == 200
    assert update_loan.json()["status"] == "Closed"
    assert update_loan.json()["outstanding_amount"] == 0.0
    print("PASS: 9. Loan payoff (marked Closed, outstanding set to ₹0, profile recalculated)")

    # 9. Dashboard API
    dash_resp = client.get(f"{BASE_URL}/dashboard", headers=headers)
    assert dash_resp.status_code == 200, f"Dashboard retrieval failed: {dash_resp.text}"
    dash_data = dash_resp.json()
    assert "cards" in dash_data
    assert "health_indicator" in dash_data
    assert "score_history_chart" in dash_data
    assert "credit_utilization_chart" in dash_data
    assert "financial_overview_chart" in dash_data
    print(f"PASS: 10. Dashboard API (Health status: '{dash_data['health_indicator']['status']}')")

    # 10. AI Financial Advisor Endpoint
    ai_resp = client.post(f"{BASE_URL}/ai/advice", json={"custom_question": "Can I qualify for a prime home loan?"}, headers=headers)
    assert ai_resp.status_code == 200, f"AI advice failed: {ai_resp.text}"
    ai_data = ai_resp.json()
    assert "summary" in ai_data
    assert "action_plan" in ai_data
    assert len(ai_data["action_plan"]) >= 4
    assert "educational_disclaimer" in ai_data
    print("PASS: 11. Gemini AI advisor integration with structured 5-step action plan & disclaimer")

    # 11. Demo Data Seeding
    demo_resp = client.post(f"{BASE_URL}/demo/load", headers=headers)
    assert demo_resp.status_code == 200, f"Demo loading failed: {demo_resp.text}"
    # Verify loaded demo data
    dash_after_demo = client.get(f"{BASE_URL}/dashboard", headers=headers).json()
    assert dash_after_demo["cards"]["credit_score"] == 735
    assert dash_after_demo["cards"]["monthly_income"] == 50000.0
    print("PASS: 12. Demo data seeding (Rajesh Sharma: ₹50k income, 735 CIBIL, active loans)")

    # 12. Demo Data Clear / Reset
    clear_resp = client.post(f"{BASE_URL}/demo/clear", headers=headers)
    assert clear_resp.status_code == 200
    print("PASS: 13. Demo data reset / clean state endpoint")

    # 13. Logout
    logout_resp = client.post(f"{BASE_URL}/auth/logout", headers=headers)
    assert logout_resp.status_code == 200
    print("PASS: 14. User logout endpoint")

    print("=" * 60)
    print("ALL 14 END-TO-END SYSTEM CAPABILITY TESTS PASSED WITH 100% SUCCESS!")
    print("=" * 60)

if __name__ == "__main__":
    run_e2e_verification()
