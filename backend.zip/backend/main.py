from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from backend.utils.config import settings
from backend.database import init_db
from backend.routers import (
    auth_router,
    users_router,
    financial_profile_router,
    credit_score_router,
    loans_router,
    dashboard_router,
    ai_router,
    demo_router
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize SQLite/Postgres tables
    init_db()
    yield
    # Shutdown logic if any

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="""
    ## Credit Assistant — AI-Powered Credit Health & Financial Wellness Platform (India)
    
    A production-ready full-stack application providing:
    - **Secure User Authentication** (JWT, Bcrypt)
    - **Financial Profile Management** (Income, Expenses, Debt, Credit Limits, CIBIL)
    - **Automated Metric Engines** (Debt-to-Income / DTI %, Credit Utilization %)
    - **CIBIL / Credit Score Tracking** (Historical changes, high/low records)
    - **Loan & EMI Portfolio Manager** (Auto-syncs debt & EMI totals)
    - **Credit Health Assessment** (Transparent rules for Indian financial benchmarks)
    - **AI Financial Advisor** (Google Gemini API with structured JSON output & resilient fallback)
    - **Interactive Visualizations** (Recharts datasets)
    - **Demo Data Generator** (Instant sample profiles for academic/industry evaluation)
    """,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Exception Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": f"An internal server error occurred: {str(exc)}"}
    )

# Register Routers under /api
app.include_router(auth_router, prefix=settings.API_PREFIX)
app.include_router(users_router, prefix=settings.API_PREFIX)
app.include_router(financial_profile_router, prefix=settings.API_PREFIX)
app.include_router(credit_score_router, prefix=settings.API_PREFIX)
app.include_router(loans_router, prefix=settings.API_PREFIX)
app.include_router(dashboard_router, prefix=settings.API_PREFIX)
app.include_router(ai_router, prefix=settings.API_PREFIX)
app.include_router(demo_router, prefix=settings.API_PREFIX)

@app.get("/", tags=["Health"])
def root():
    return {
        "app": "Credit Assistant API",
        "version": settings.VERSION,
        "status": "online",
        "ecosystem": "India (CIBIL / INR ₹)",
        "docs": "/docs",
        "api_prefix": settings.API_PREFIX
    }

@app.get("/health", tags=["Health"])
def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run("backend.main:app", host="0.0.0.0", port=settings.PORT, reload=True)
