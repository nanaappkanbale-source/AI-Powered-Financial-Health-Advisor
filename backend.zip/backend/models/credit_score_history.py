from datetime import datetime, timezone
from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.database import Base

class CreditScoreHistory(Base):
    __tablename__ = "credit_score_histories"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    credit_score = Column(Integer, nullable=False)
    score_change = Column(Integer, default=0, nullable=False) # e.g. +25, -10, 0
    recorded_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    user = relationship("User", back_populates="credit_score_history")
