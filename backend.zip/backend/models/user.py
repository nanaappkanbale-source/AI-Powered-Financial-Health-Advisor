from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from backend.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    financial_profile = relationship("FinancialProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    credit_score_history = relationship("CreditScoreHistory", back_populates="user", cascade="all, delete-orphan", order_by="desc(CreditScoreHistory.recorded_at)")
    loans = relationship("Loan", back_populates="user", cascade="all, delete-orphan", order_by="desc(Loan.id)")
    ai_recommendations = relationship("AIRecommendation", back_populates="user", cascade="all, delete-orphan", order_by="desc(AIRecommendation.created_at)")
