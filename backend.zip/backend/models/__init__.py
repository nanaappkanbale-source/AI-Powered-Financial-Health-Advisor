from backend.database import Base
from backend.models.user import User
from backend.models.financial_profile import FinancialProfile
from backend.models.credit_score_history import CreditScoreHistory
from backend.models.loan import Loan
from backend.models.ai_recommendation import AIRecommendation

__all__ = [
    "Base",
    "User",
    "FinancialProfile",
    "CreditScoreHistory",
    "Loan",
    "AIRecommendation",
]
