from datetime import datetime, timezone
from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.database import Base

class Loan(Base):
    __tablename__ = "loans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    loan_name = Column(String(150), nullable=False) # e.g. "HDFC Home Loan", "SBI Personal Loan"
    principal_amount = Column(Float, nullable=False)
    outstanding_amount = Column(Float, nullable=False)
    emi = Column(Float, nullable=False)
    interest_rate = Column(Float, default=10.5, nullable=False) # Percentage per annum
    start_date = Column(String(50), nullable=True) # ISO string or YYYY-MM-DD
    end_date = Column(String(50), nullable=True)
    status = Column(String(30), default="Active", nullable=False) # "Active" or "Closed" / "Paid"
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="loans")
