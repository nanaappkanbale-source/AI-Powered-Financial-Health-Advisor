from datetime import datetime, timezone
from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.database import Base

class FinancialProfile(Base):
    __tablename__ = "financial_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False, index=True)
    
    # Financial metrics (Indian Rupees ₹)
    income = Column(Float, default=0.0, nullable=False)
    expenses = Column(Float, default=0.0, nullable=False)
    credit_score = Column(Integer, default=650, nullable=False)
    total_debt = Column(Float, default=0.0, nullable=False)
    credit_limit = Column(Float, default=0.0, nullable=False)
    credit_utilization = Column(Float, default=0.0, nullable=False) # In percent %
    dti_ratio = Column(Float, default=0.0, nullable=False)          # In percent %
    missed_payments = Column(Integer, default=0, nullable=False)
    active_loans = Column(Integer, default=0, nullable=False)
    monthly_emi = Column(Float, default=0.0, nullable=False)
    financial_goal = Column(String(255), default="Improve CIBIL Score to 750+", nullable=False)
    
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="financial_profile")
